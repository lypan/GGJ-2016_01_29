﻿using UnityEngine;
using System.Collections;

public class midAttack : MonoBehaviour {
	public GameObject target;
	public GameObject bullet;
	public int maxCount;
	public float attackDistance;
	public Vector2 offset;
	private bool _hasFired;
	private bool _canFire;
	private int _count;
	private GameObject _head;
	private GameObject _fpoint;

	// Use this for initialization
	void Start () {
		_head = transform.GetChild(0).gameObject;
		_fpoint = transform.GetChild(1).gameObject;
		Debug.Log (_head.gameObject.name);
		Debug.Log (_fpoint.gameObject.name);
		_hasFired = false;
		_canFire = true;
		_count = 0;
	}
	
	// Update is called once per frame
	void Update () {
		if (_hasFired) {
			_count++;
			_head.GetComponent<Animator> ().SetBool("attack", false);

		}
		if (_count == maxCount) {
			_count = 0;
			_canFire = true;
			_hasFired = false;
		}
		if (target.transform.position.x < transform.position.x) {
			CheckTarget ();
		}
		
	}
	void CheckTarget () {
		if (Vector3.Distance (target.transform.position, transform.position) < attackDistance && _canFire) {
			Vector2 raycastOrigin = new Vector2 (transform.position.x + offset.x, transform.position.y + offset.y);
			RaycastHit2D hit = Physics2D.Raycast (raycastOrigin, Vector2.right, Mathf.Infinity);
			Debug.DrawRay (raycastOrigin, new Vector2(target.transform.position.x - transform.position.x, target.transform.position.y - transform.position.y) * 10, Color.red);

			if (hit && _canFire) {
				_head.GetComponent<Animator> ().SetBool("attack", true);
				Debug.Log ("Fire");
				GameObject ibullet = Instantiate (bullet, new Vector3(transform.position.x + offset.x, transform.position.y + offset.y, 0), transform.rotation) as GameObject;
				ibullet.GetComponent<Rigidbody2D> ().velocity = new Vector2 (target.transform.position.x - transform.position.x, target.transform.position.y - transform.position.y) * 3;
				_hasFired = true;
				_canFire = false;
			}
		}
	}
}
