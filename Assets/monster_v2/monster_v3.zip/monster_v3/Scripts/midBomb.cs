﻿using UnityEngine;
using System.Collections;

public class midBomb : MonoBehaviour {
	private Animator _animator;
	// Use this for initialization
	void Start () {
		_animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter2D(Collision2D col) {
		if (col.gameObject.tag == "Player") {
			Debug.Log ("ha");
			_animator.SetTrigger ("bomb");
		}
	}
}
